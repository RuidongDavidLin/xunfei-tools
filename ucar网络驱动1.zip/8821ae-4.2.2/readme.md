## 本驱动包只针对晓mini版本小车 ##
## 晓mini版本驱动请安装4.2.2版本 ##
1、解压附件 

2、删除掉镜像中的旧驱动 

sudo rm /lib/modules/4.9.140-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtl8821ae/rtl8821ae.ko 

3、将解压后对应镜像版本的ko文件拷贝到镜像中： 

sudo cp 8821ae.ko /lib/modules/4.9.140-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtl8821ae/ 

4、执行下面命令 

sudo depmod 

5、重启 

