This is the camera "TOOLS_TOP/settings" folder.

Settings and overrides files used by camera go here.
